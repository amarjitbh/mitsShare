<div id="review-modal-top" class="latest-reviews product-detail-latest-reviews">
    <div class="product-detail-latest-reviews-list">
<div class="modal fade" id="reviewModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><b>View All Reviews</b></h4>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <div id="ajax-reviews" class="product-detail-latest-reviews-list">

                    </div>
                    <button type="button" id="load-more" class="btn green">Load More</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="close-modal" class="btn green" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
    </div>
</div>