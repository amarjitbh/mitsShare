<p>Hi Please click on this <a href="{{route('reset.password')}}?token={{$content}}"> to change  your Password</p>

