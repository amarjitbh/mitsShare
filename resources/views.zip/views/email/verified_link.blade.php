<p>Hi Please click on this <a href="{{route('verify.useremail')}}?verify_link={{$content}}"> to verify your email</p>

