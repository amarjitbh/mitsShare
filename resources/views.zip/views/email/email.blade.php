@extends('layouts.email')
@section('title', 'Email')

@section('content')
    {!! $body !!}
@endsection